package login.sqllogin;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class HelloController {
    @FXML
    private Label statusLabel;
    @FXML
    private Button loginButton;
    @FXML
    private TextField userField;
    @FXML
    private TextField passField;
    @FXML
    private Label registerLabel;
    @FXML
    private Button registerButton;
    @FXML
    private TextField newUserField;
    @FXML
    private TextField newPasswordField;
    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField newPasswordConfField;

    private Connection connection;
    private Statement statement;

    private String insert = "insert into users (";


    @FXML
    public void initialize() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/userbase", "root", "Kxz24y33");
            statement = connection.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void onLoginClick() {
        String un = userField.getText();
        String pw = passField.getText();

        if(un.isEmpty() || pw.isEmpty()) {
            statusLabel.setText("Please fill out all fields");
        } else {
            statusLabel.setText("Logged in, welcome " + un + "!");
        }
    }

    @FXML
    protected void onRegisterClick() {
        String un = newUserField.getText();
        String pw = newPasswordField.getText();
        String pc = newPasswordConfField.getText();
        String fn = firstNameField.getText();
        String ln = lastNameField.getText();
        String em = emailField.getText();

        if(un.isEmpty() || pw.isEmpty() || fn.isEmpty() || ln.isEmpty() || em.isEmpty()) {
            registerLabel.setText("Please fill out all fields");
        } else if(!pw.equals(pc)) {
            registerLabel.setText("Passwords do not match");
        } else {

            try {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/userbase", "root", "Kxz24y33");
                statement = connection.createStatement();

                statement.executeUpdate("INSERT INTO users VALUES(" +
                        quoter(un) + ", " +
                        quoter(pw) + ", " +
                        quoter(fn) + ", " +
                        quoter(ln) + ", " +
                        quoter(em) + ")");

                connection.close();
            } catch(Exception e) {
                e.printStackTrace();
            }
            registerLabel.setText("Registered, welcome " + un + "!");
        }
    }

    public String quoter(String x) {
        return "'" + x + "'";
    }
}