module login.sqllogin {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens login.sqllogin to javafx.fxml;
    exports login.sqllogin;
}